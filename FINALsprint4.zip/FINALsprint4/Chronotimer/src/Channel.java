import java.time.LocalTime;

public class Channel {
	int channelNum;
	LocalTime time;
	boolean enable = false;
	String sens = null;
	
	LocalTime t = LocalTime.now();
	
	public Channel(int num) {
		channelNum = num;
	}
	
	public void toggle() {
		if (enable) enable = false;
		else enable = true;
	}
	
	public void trigger() {
		if (enable) time = t;
		
	}
	
	public void connect(String sensor) {
		if (enable) {
			switch(sensor) {
			case "EYE":
				sens = "EYE";
				break;
			case "GATE":
				sens = "GATE";
				break;
			case "PAD":
				sens = "PAD";
				break;
			}
		}
	}
	
	public void disconnect() {
			sens = null;
		}

}
