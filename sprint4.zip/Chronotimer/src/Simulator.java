import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Simulator {

	static DateFormat formatter = new SimpleDateFormat("h:mm:ss:S");
	static ChronoTimer ct = new ChronoTimer();

	public final static void main(String[] args) {
		Gson g = new Gson();
		Scanner input = new Scanner(System.in);
		String next;
		String[] line;

		System.out
				.println("Would you like to simulate in physical view? yes/no:");
		next = input.nextLine();
		if (next.equalsIgnoreCase("yes")) {
			new ChronoView();
		} else {
			ChronoTimer ct = new ChronoTimer();

			do {
				System.out
						.print("Enter a command (\"exit\") to finish (\"load <filename>\") to load file: ");

				next = input.nextLine();
				line = next.split(" ");
				if (next.equalsIgnoreCase("exit")) {
					try (Writer w = new FileWriter("Output.txt")) {
						Gson gson = new GsonBuilder().create();
						gson.toJson(ct, w);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else if (line[0].equalsIgnoreCase("load")) {
					List<String> commandLines = getCommands(line[1]);
					for (String commandLine : commandLines) {
						processCommand(commandLine.toUpperCase());
					}
				} else {
					Date d = new Date();
					next = formatter.format(d) + " " + next;
					processCommand(next.toUpperCase());
				}
			} while (!next.equalsIgnoreCase("exit"));
		}
	}

	public static void processCommand(String command) {
		String[] cmd;
		cmd = command.split(" ");
		System.out.println("echo: " + command);
		
		if (!(ct.power) && !(cmd[1].equals("POWER"))){
			System.out.println("No Power");
		}

		else if (cmd[1].equals("CANCEL")) {
			// remove current run for racer and queue as next to start.
			if (cmd.length != 3) {
				System.out.println("Controller: Invalid number of args");
				return;
			}
			ct.cancel();
		} else if (cmd[1].equals("CONN")) {
			// connect a type of sensor to a panel. Types: {EYE, GATE, PAD}.
			if (cmd.length != 4) {
				System.out.println("Controller: Invalid number of args");
				return;
			}
			ct.connectChannel(Integer.parseInt(cmd[3]), cmd[2]);
		} else if (cmd[1].equals("DNF")) {
			// next competitor to finish will not finish.
			ct.dnf();
		} else if (cmd[1].equals("ENDRUN")) {
			// done with run.
			ct.endRun();
		} else if (cmd[1].equals("EVENT")) {
			// create an event of type: {IND | PARIND | GRP | PARGRP}.
			ct.setEvent(cmd[2]);
		} else if (cmd[1].equals("FINISH")) {
			// shorthand for TRIG 2.
			ct.trigger(2, cmd[0]);
		} else if (cmd[1].equals("NEWRUN")) {
			// create a new run.
		} else if (cmd[1].equals("NUM")) {
			// set num as next competitor to start.
			ct.setRunner(Integer.parseInt(cmd[2]));
		} else if (cmd[1].equals("PRINT")) {
			// print results
			ct.print();
		} else if (cmd[1].equals("POWER")) {
			// turn chronotimer on/off.
			ct.power();
		} else if (cmd[1].equals("RESET")) {
			// reset system to initial state.
			ct = new ChronoTimer();
		} else if (cmd[1].equals("START")) {
			// shorthand for TRIG 1.
			ct.trigger(1, cmd[0]);
		} else if (cmd[1].equals("TIME")) {
			// set the current time
		} else if (cmd[1].equals("TOG")) {
			// toggle state of the channel
			ct.toggle(Integer.parseInt(cmd[2]));
		} else if (cmd[1].equals("TRIG")) {
			// trigger channel
			if (cmd.length > 3) {
				ct.groupTrigger(Integer.parseInt(cmd[2]), cmd[0], cmd[3]);
			} else {
				ct.trigger(Integer.parseInt(cmd[2]), cmd[0]);
			}
		} else if (cmd[1].equals("SETRACE")) {
			ct.setRace(cmd[2]);
		} else {
			System.out.println("Controller: Invalid command");
		}
	}

	public static List<String> getCommands(String fileName) {
		if (fileName == null)
			return new ArrayList<String>(0);
		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();
		File file = new File(classLoader.getResource("resources/" + fileName)
				.getFile());
		if (!(file.exists() && file.canRead())) {
			System.err
					.println("Cannot access file! Non-existent or read access restricted");
			return new ArrayList<String>(0);
		}

		List<String> commandLines = new ArrayList<String>(32);
		Scanner scanner;
		try {
			scanner = new Scanner(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		while (scanner.hasNextLine()) {
			commandLines.add(scanner.nextLine());
		}

		scanner.close();

		return commandLines;
	}
}