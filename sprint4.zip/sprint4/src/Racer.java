
public class Racer {
	Time startTime;
	Time endTime;//DNF time class
	
	int num;
	String name;
	
	boolean isRunning = false;
	boolean completed = false;//DNF time class
	
	public Racer(int rNum,String name) {
		this.num = rNum;
		this.name = name;
	}
	public void setNum(int rNum) {
		num = rNum;
	}
	public void setName(String name){
		this.name = name;
	}
	
	public int getNum(){
		return num;
	}
	public void setRunning(boolean bool){
		isRunning = bool;
	}
	public void finished(String time){
			endTime = new Time(time);
			completed = true;
	}
	public boolean getFinished(){
		return completed;
	}
	public void setStart(String time) {
		startTime = new Time(time);
	}
	public String finishTime() {
		return Time.difference(startTime, endTime);
	}
	
}
