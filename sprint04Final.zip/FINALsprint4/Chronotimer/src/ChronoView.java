import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
public class ChronoView implements ActionListener{
//	 JTextField tf1,tf2,tf3, tf4, tf5, tf6;  
	 JLabel start, end1, end2, finish, title;
	 JButton power, prtpwr, func, swap, add,
	 	zero, one, two, three, four, five, six, seven, eight, nine, lb, star; 
	 JRadioButton s1, s3, s5, s7, e1, e2, e3, e4, e5, 
	 	e6, e7, e8, f2, f4, f6, f8, b1, b2, b3, b4, b5, b6, b7, b8, r1, r2, r3, r4;
	 
	 ButtonGroup t = new ButtonGroup();
	 ButtonGroup event = new ButtonGroup();
	 ChronoTimer ct;
	 String no = "";
	 JTextArea printer;
	 boolean prtPower = false;
	 String printS = "off \n";
	 static DateFormat formatter = new SimpleDateFormat("h:mm:ss:S");
	 
	public ChronoView() {
		// need to do - printer text box and console text box
		ct = new ChronoTimer();
		JFrame f= new JFrame();  
		
		class CustomOutputStream extends OutputStream {
		    private JTextArea textArea;
		     
		    public CustomOutputStream(JTextArea textArea) {
		        this.textArea = textArea;
		    }
		     
		    @Override
		    public void write(int b) throws IOException {
		        // redirects data to the text area
		        textArea.append(String.valueOf((char)b));
		        // scrolls the text area to the end of data
		        textArea.setCaretPosition(textArea.getDocument().getLength());
		    }
		}

		//console
		JTextArea textArea = new JTextArea(400, 400);
		textArea.setBounds(200, 350, 400, 400);
		PrintStream printStream = new PrintStream(new CustomOutputStream(textArea));
		System.setOut(printStream);
		System.setErr(printStream);

		//printer text field
		printer = new JTextArea(200, 200);
		printer.setBounds(700, 100, 200, 150);
		setPrinter(printS);
		//printer.setEditable(false);
		DefaultCaret caret = (DefaultCaret)printer.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
       
        s1 = new JRadioButton("1s");
        s1.setBounds(150,150,100,20);
        s3 = new JRadioButton("3s");
        s3.setBounds(250,150,100,20);
        s5 = new JRadioButton("5s");
        s5.setBounds(350,150,100,20);
        s7 = new JRadioButton("7s");
        s7.setBounds(450,150,100,20);
        t.add(s1);
        t.add(s3);
        t.add(s5);
        t.add(s7);
        
        e1 = new JRadioButton("1e");
        e1.setBounds(150,200,100,20);
        e3 = new JRadioButton("3e");
        e3.setBounds(250,200,100,20);
        e5 = new JRadioButton("5e");
        e5.setBounds(350,200,100,20);
        e7 = new JRadioButton("7e");
        e7.setBounds(450,200,100,20);
        t.add(e1);
        t.add(e3);
        t.add(e5);
        t.add(e7);
        
        f2 = new JRadioButton("2f");
        f2.setBounds(150,250,100,20);
        f4 = new JRadioButton("4f");
        f4.setBounds(250,250,100,20);
        f6 = new JRadioButton("6f");
        f6.setBounds(350,250,100,20);
        f8 = new JRadioButton("8f");
        f8.setBounds(450,250,100,20);
        t.add(f2);
        t.add(f4);
        t.add(f6);
        t.add(f8);
        
        r1 = new JRadioButton("IND");
        r1.setBounds(50,400,100,20);
        event.add(r1);
        r2 = new JRadioButton("PARIND");
        r2.setBounds(100,400,100,20);
        event.add(r2);
        r3 = new JRadioButton("GRP");
        r3.setBounds(50,450,100,20);
        event.add(r3);
        r4 = new JRadioButton("PARGRP");
        r4.setBounds(100,450,100,20);
        event.add(r4);
        
        
        e2 = new JRadioButton("2e");
        e2.setBounds(150,300,100,20);
        e4 = new JRadioButton("4e");
        e4.setBounds(250,300,100,20);
        e6 = new JRadioButton("6e");
        e6.setBounds(350,300,100,20);
        e8 = new JRadioButton("8e");
        e8.setBounds(450,300,100,20);
        t.add(e2);
        t.add(e4);
        t.add(e6);
        t.add(e8);
        
        title=new JLabel("Chronotimer 1009");  
        title.setBounds(400,50,100,20);  
        start=new JLabel("start");  
        start.setBounds(50,150, 100,20); 
        end1=new JLabel("enable/disable");  
        end1.setBounds(50,200, 100,20);  
        finish=new JLabel("finish");  
        finish.setBounds(50,250, 100,20); 
        end2=new JLabel("enable/disable");  
        end2.setBounds(50,300, 100,20);

   
         
        power=new JButton("Power");  
        power.setBounds(50,50,100,50);  
        func=new JButton("Function");
        func.setBounds(50, 350, 100, 50);
        swap = new JButton("Swap");
        swap.setBounds(50, 550, 100, 50);
        prtpwr = new JButton("Print");
        prtpwr.setBounds(750, 50, 100, 50);
        add =new JButton("Add Runner");
        add.setBounds(750, 500, 100, 50);
        
        zero=new JButton("0");  
        zero.setBounds(700,300,50,50);
        one=new JButton("1");  
        one.setBounds(750,300,50,50); 
        two=new JButton("2");  
        two.setBounds(800,300,50,50); 
        three=new JButton("3");  
        three.setBounds(700,350,50,50); 
        four=new JButton("4");  
        four.setBounds(750,350,50,50);
        five=new JButton("5");  
        five.setBounds(800,350,50,50); 
        six=new JButton("6");  
        six.setBounds(700,400,50,50);
        seven=new JButton("7");  
        seven.setBounds(750,400,50,50); 
        eight=new JButton("8");  
        eight.setBounds(800,400,50,50);
        star=new JButton("*");  
        star.setBounds(700,450,50,50);
        nine=new JButton("9");  
        nine.setBounds(750,450,50,50); 
        lb=new JButton("#");  
        lb.setBounds(800,450,50,50); 
        
       // b1.addActionListener(this);  
//        f.add(b1); 
        f.add(r1);f.add(r2);f.add(r3);f.add(r4);
        f.add(e1);f.add(e3);f.add(e5);f.add(e7);f.add(s1);f.add(s3);
        f.add(s5);f.add(s7);f.add(title);f.add(start);f.add(end1);
        f.add(f2);f.add(f4);f.add(f6);f.add(f8);f.add(finish);
        f.add(e2);f.add(e4);f.add(e6);f.add(e8);f.add(end2);
        f.add(power);f.add(func);f.add(swap);f.add(prtpwr);f.add(add);
        f.add(zero);f.add(one);f.add(two);f.add(three);f.add(four);f.add(five);f.add(six);
        f.add(seven);f.add(eight);f.add(nine);f.add(star);f.add(lb);
        f.add(printer); f.add(textArea);
        f.setSize(1000,1000);  
        f.setLayout(null);  
        f.setVisible(true);  
        

	 
	 	power.addActionListener(this);
	 	prtpwr.addActionListener(this);
	 	func.addActionListener(this);
	 	swap.addActionListener(this);
	 	zero.addActionListener(this);
	 	one.addActionListener(this);
	 	two.addActionListener(this);
	 	three.addActionListener(this);
	 	four.addActionListener(this);
	 	five.addActionListener(this);
	 	six.addActionListener(this);
	 	seven.addActionListener(this);
	 	eight.addActionListener(this);
	 	nine.addActionListener(this);
	 	lb.addActionListener(this);
	 	star.addActionListener(this);
	 	s1.addActionListener(this);
	 	s3.addActionListener(this);
	 	s5.addActionListener(this);
	 	s7.addActionListener(this);
	 	e1.addActionListener(this);
	 	e2.addActionListener(this);
	 	e3.addActionListener(this);
	 	e4.addActionListener(this);
	 	e5.addActionListener(this);
	 	e6.addActionListener(this);
	 	e7.addActionListener(this);
	 	e8.addActionListener(this);
	 	f2.addActionListener(this);
	 	f4.addActionListener(this);
	 	f6.addActionListener(this);
	 	f8.addActionListener(this);
	 	add.addActionListener(this);
	 	r1.addActionListener(this);
	 	r2.addActionListener(this);
	 	r3.addActionListener(this);
	 	r4.addActionListener(this);
	 	
	 	
    }       

	public void setPrinter(String text) {
        printer.setText(text);

    }
	
    public void actionPerformed(ActionEvent e) {  
    	 Object o = e.getSource();
    	 Date d = new Date();
    	 String time = formatter.format(d);
    	 
  		 
  		 if (o == power){
  			 ct.power();
  		 }
  		 else if (o == prtpwr){
  			 ct.print();
  			 ct.endRun();
  		 }
  		 else if (o == func){
  			 
  				 printS += "func \n";
  				 setPrinter(printS);
  			 
  		 }
  		 else if (o == add) {
  				 printS += "Add runner " + no + "\n";
  				 setPrinter(printS);
  			 
  			 if (no.length() > 0) ct.setRunner(Integer.parseInt(no));
  			 no = "";
  		 }
  		 else if (o == swap){
 				 printS += "swap \n";
 				 setPrinter(printS);
 			 
  		 }
  		 else if (o == r1){
 			 ct.setEvent("IND");
 				 printS += "IND \n";
 				 setPrinter(printS);
 			 
 		 }
  		 else if (o == r2){
  			ct.setEvent("PARIND");
 				 printS += "PARIND \n";
 				 setPrinter(printS);
 			 
 		 }
  		 else if (o == r3){
  			ct.setEvent("GRP");
 				 printS += "GRP \n";
 				 setPrinter(printS);
 			 
 		 }
  		 else if (o == r4){
  			ct.setEvent("PARGRP");
 				 printS += "PARGRP \n";
 				 setPrinter(printS);
 			 
 		 }
  		 else if (o == zero){
  			 no+="0";
  		 }
  		 else if (o == one){
  			 no+="1";
  		 }
  		 else if (o == two){
  			 no+="2";
  		 }
  		 else if (o == three){
  			 no+="3";
  		 }
  		 else if (o == four){
  			 no+="4";
  		 }
  		 else if (o == five){
  			 no+="5";
  		 }
  		 else if (o == six){
  			 no+="6";
 		 }
  		 else if (o == seven){
  			 no+="7";
 		 }
  		 else if (o == eight){
  			 no+="8";
 		 }
  		 else if (o == nine){
  			 no+="9";
 		 }
  		 else if (o == lb){
  			int runner = Integer.parseInt(no);
 			 ct.setRunner(runner);
 				 printS += "New player: " + no + "\n";
 				 setPrinter(printS);
 			 
 			 no = "";
 		 }
  		 else if (o == star){
  			 no+="*";
 		 }
  		else if (o == s1){
 			 ct.trigger(1, time);
 			
 				 printS += "Trigger channel 1 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == s3){
 			 ct.trigger(3, time);
 			 	 printS += "Trigger channel 3 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == s5){
 			 ct.trigger(5, time);
 			 	 printS += "Trigger channel 5 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == s7){
 			 ct.trigger(7, time);
 			 	 printS += "Trigger channel 7 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e1){
 			 ct.toggle(1);
 			 	 printS += "Toggle channel 1 \n";
 				 setPrinter(printS);
 			 }
 		 
 		 else if (o == e2){
 			 ct.toggle(2);
 			 	 printS += "Toggle channel 2 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e3){
 			 ct.toggle(3);
 			 	 printS += "Toggle channel 3 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e4){
 			 ct.toggle(4);
 			 	 printS += "Toggle channel 4 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e5){
 			 ct.toggle(5);
 			 	 printS += "Toggle channel 5 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e6){
 			 ct.toggle(6);
 			 	 printS += "Toggle channel 6 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e7){
 			 ct.toggle(7);
 				 printS += "Toggle channel 7 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == e8){
 			 ct.toggle(8);
 			 	 printS += "Toggle channel 8 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == f2){
 			 ct.trigger(2, time);
 				 printS += "Trigger channel 2 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == f4){
 			 ct.trigger(4, time);
 			 	 printS += "Trigger channel 4 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == f6){
 			 ct.trigger(6, time);
 			 	 printS += "Trigger channel 6 \n";
 				 setPrinter(printS);
 			 
 		 }
 		 else if (o == f8){
 			 ct.trigger(8, time);
 			 	 printS += "Trigger channel 8 \n";
 				 setPrinter(printS);
 			 
 		 }
    }  
	
}
