import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.util.ArrayList;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ChronoTimer {
	boolean power = false;

	Time endTime;
	Race r1 = new Race();
	ArrayList<Racer> queued = new ArrayList<Racer>();
	ArrayList<Racer> running = new ArrayList<Racer>();
	ArrayList<Racer> finished = new ArrayList<Racer>();
	ArrayList<Racer> DNF = new ArrayList<Racer>();

	int runs = 1;

	Channel c1 = new Channel(1);
	Channel c2 = new Channel(2);
	Channel c3 = new Channel(3);
	Channel c4 = new Channel(4);
	Channel c5 = new Channel(5);
	Channel c6 = new Channel(6);
	Channel c7 = new Channel(7);
	Channel c8 = new Channel(8);

	public ChronoTimer() {

	}

	public void setRace(Race r) {
		r1 = r;
	}

	public boolean setRace(String fileName) {
		
		if (fileName == null)
			return false;
		ClassLoader classLoader = Thread.currentThread()
				.getContextClassLoader();

		
		
		Gson g = new Gson();
		FileReader fr;
		try {
			
			File file = new File(classLoader.getResource("resources/" + fileName).getFile());
			fr = new FileReader(file);
			Race temp = g.fromJson(fr,Race.class);
			setRace(temp);
			queued.clear();
			for(int i = 0; i < r1.racers.size(); ++i) {
				queued.add(r1.racers.get(i));
			}
		} catch (NullPointerException | FileNotFoundException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			printConsole("File not found!");
			return false;
		}
		
		
		
		return true;
	}

	public void setEvent(String event) {
		r1.setRaceType(event);
		printConsole("Event set to " + event);
	}

	public void printConsole(String input) {
		System.out.println("console: " + input);
	}

	public boolean power() {
		power = !power;
		if (power) {
			printConsole("System is on.");
		} else {
			printConsole("System is off.");
		}
		return power;
	}

	public void connectChannel(int channel, String sensor) {
		if (sensor.equals("EYE") || sensor.equals("GATE") || sensor.equals("PAD")) {
			switch (channel) {
			case 1:
				if (c1.sens.equals("none")) {
					c1.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");	
				break;
			case 2:
				if (c2.sens.equals("none")) {
					c2.connect(sensor);
					printConsole("channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");
					
				break;
			case 3:
				if (c3.sens.equals("none")) {
					c3.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");		
				break;
			case 4:
				if (c4.sens.equals("none")) {
					c4.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");		
				break;
			case 5:
				if (c5.sens.equals("none")) {
					c5.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");		
				break;
			case 6:
				if (c6.sens.equals("none")) {
					c6.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");		
				break;
			case 7:
				if (c7.sens.equals("none")) {
					c7.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");
				break;
			case 8:
				if (c8.sens.equals("none")) {
					c8.connect(sensor);
					printConsole("Channel " + channel + " is now connected to "
							+ sensor + " sensor.");
				} else printConsole("Channel " + channel + " already connected to a sensor");		
				break;
			}
		} else printConsole("Sensor not recognized");
	}
	
	public void disconnect(int channel) {
		switch (channel){
		case 1: 
			c1.disconnect(); break;
		case 2: 
			c2.disconnect(); break;
		case 3: 
			c3.disconnect(); break;
		case 4:
			c4.disconnect(); break;
		case 5:
			c5.disconnect(); break;
		case 6:
			c6.disconnect(); break;
		case 7:
			c7.disconnect(); break;
		case 8: 
			c8.disconnect(); break;
		}
		printConsole("Sensor has been disconnected from Channel " + channel);
	}

	public void toggle(int n) {
		switch (n) {
		case 1:
			c1.toggle();
			if (c1.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 2:
			c2.toggle();
			if (c2.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 3:
			c3.toggle();
			if (c3.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 4:
			c4.toggle();
			if (c4.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 5:
			c5.toggle();
			if (c5.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 6:
			c6.toggle();
			if (c6.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 7:
			c7.toggle();
			if (c7.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		case 8:
			c8.toggle();
			if (c8.enable) printConsole("Channel " + n + " is ready to record time.");
			else printConsole("Cannel " + n + " has been turned off.");
			break;
		}
	}

	public void setRunner(int num) {// adds runner to racequeue based off their
									// number
		if (r1.getRacer(num) != null) {
			queued.add(r1.getRacer(num));
		} else {
			Racer r = new Racer(num, "Unnamed");
			r1.addRacer(r);
			queued.add(r);

		}
		printConsole("Racer " + num + " has been added to queue.");
	}

	public boolean clear(int num) {
		Racer temp = r1.getRacer(num);
		if (temp != null) {
			queued.remove(temp);
			return true;
		}
		return false;
	}

	public void trigger(int channel, String time) {

		if (!r1.racetype.equals("PARGRP")) {
			if (channel == 1 || channel == 3) {
				if (!c1.enable) {
					printConsole("Channel " + channel + " is not active");
				} else if (!queued.isEmpty()) {

					Racer racer = queued.remove(0);
					running.add(racer);
					racer.setStart(time);
					printConsole("Racer " + racer.num
							+ " starts running at time " + time);
					if (r1.racetype.equals("GRP") && !queued.isEmpty()) {
						r1.setStart(time);
						trigger(channel, time);
					}

				} else {
					printConsole("There are no racers queued to start.");

				}

			} else if (channel == 2 || channel == 4) {
				if (!c2.enable) {
					printConsole("Channel " + channel + " is not active");
				} else if (!running.isEmpty()) {
					if (r1.racetype.equals("IND")) {
						Racer racer = running.remove(0);
						finished.add(0, racer);
						racer.finished(time);
						printConsole("Racer " + racer.num
								+ " finishes running at time " + time);
					}
					if (r1.racetype.equals("PARIND")) {
						Racer racer = running.remove(0);
						finished.add(0, racer);
						racer.finished(time);
						printConsole("Racer " + racer.num
								+ " finishes running at time " + time);
					}

				} else {
					printConsole("There are no racers currently running.");
				}
			} else {
				printConsole("Only channels 1, 2, 3 and 4 are being used.");
			}
		} else
			PGtrigger(channel, time);
	}

	public void groupTrigger(int channel, String time, String rNum) {
		int num = Integer.parseInt(rNum);
		Racer racer = r1.getRacer(num);
		if (racer != null) {
			if(racer.isRunning) {
				running.remove(racer);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num + " finishes running at time "
						+ time);
			}
		} else {
			printConsole("Invalid racer number entered!");
		}
	}
	

	public void PGtrigger(int channel, String time) {
		if (!(c1.enable)){
			printConsole("Channel 1 is not active");
		}
		if (running.isEmpty() && channel == 1) {
			for (int i = 0; i <= 7 && (queued.size() != 0); i++) {
				Racer racer = queued.remove(0);
				running.add(racer);
				racer.setStart(time);
				printConsole("Racer " + racer.num + " starts running at time "
						+ time);
			}
		} else if (!running.isEmpty()) {
			if (channel == 1 && !(running.get(0) == null)) {
				Racer racer = running.get(0);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(0, null);
			} else if (channel == 2 && c2.enable && !(running.get(1) == null)) {
				Racer racer = running.get(1);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(1, null);
			} else if (channel == 3 && c3.enable && !(running.get(2) == null)) {
				Racer racer = running.get(2);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(2, null);
			} else if (channel == 4 && c4.enable && !(running.get(3) == null)) {
				Racer racer = running.get(3);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(3, null);
			} else if (channel == 5 && c5.enable && !(running.get(4) == null)) {
				Racer racer = running.get(4);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(4, null);
			} else if (channel == 6 && c6.enable && !(running.get(5) == null)) {
				Racer racer = running.get(5);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(5, null);
			} else if (channel == 7 && c7.enable && !(running.get(6) == null)) {
				Racer racer = running.get(6);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(6, null);
			} else if (channel == 8 && c8.enable && !(running.get(7) == null)) {
				Racer racer = running.get(7);
				finished.add(0, racer);
				racer.finished(time);
				printConsole("Racer " + racer.num
						+ " finishes running at time " + time);
				running.set(7, null);
			}

			int i = 0;
			while (i < running.size() && running.get(i) == null) {
				i++;
			}
			if (i == running.size()) {
				running.clear();
			}
		}
	}

	public void cancel() {
		queued.add(0, running.remove(0));
	}

	public void print() {//prints race results and exports to gson text file
		printConsole("-----FINAL RESULTS-----");
		for (Racer racer : finished) {
			printConsole("Racer " + racer.num + " " + racer.finishTime());
		}
		for (Racer racer : running) {
			if (racer != null) {
				DNF.add(0, racer);
			}
		}
		running.clear();
		for (Racer racer : DNF) {
			printConsole("Racer " + racer.num + " DNF");
		}
//		try (Writer w = new FileWriter("RUN" + runs + ".txt")) {
//			Gson gson = new GsonBuilder().create();
//			gson.toJson(r1, w);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		export();
	}
	public void export(){//exports race to gson format in text file
		
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		String path = classLoader.getResource("resources/").toString();
		StringBuffer text = new StringBuffer(path);
		String p2 = path.substring(6, path.length());
		try {
			File file = new File(p2 + "RUN" + runs + ".txt");
			file.setWritable(true);
			Writer w = new FileWriter(file);
			Gson gson = new GsonBuilder().create();
			gson.toJson(r1, w);//r1 or this
			w.close();
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void swap() {
		if ((r1.racetype.equals("PARGRP"))){
			printConsole("SWAP unavailable for Parallel Group Race");
		}
		else if (running.size() >= 2){
			Racer racer1 = running.get(0);
			Racer racer2 = running.get(1);
			running.set(0, racer2);
			running.set(1, racer1);
			printConsole("Racer " + running.get(0).getNum() + " Swapped with Racer " + running.get(1).getNum());
		} else {
			printConsole("Not enough racers to swap");
		}
	}

	public void dnf() {
		if (r1.racetype.equals("PARGRP")) {
			for(int i = 0; i < running.size(); ++i) {
				if(running.get(i) != null) {
					DNF.add(running.get(i));
					running.set(i, null);
					i = running.size() +1;
				}
			}
		} else {
			if(running.get(0) != null) {
				DNF.add(running.get(0));
				running.remove(0);
			}
		}
	}

	public void endRun() {
		++runs;
		for(Racer racer : running) {
			DNF.add(racer);
		}
		sendResults();
		queued.clear();
		running.clear();
		finished.clear();
		r1.setRaceType("IND");
	}
	
	public void sendResults() {
	try {
		URL site = new URL("http://localhost:8000/sendresults");
		HttpURLConnection conn = (HttpURLConnection) site.openConnection();

		conn.setRequestMethod("POST");
		conn.setDoOutput(true);
		conn.setDoInput(true);
		DataOutputStream out = new DataOutputStream(conn.getOutputStream());

		String content = "----Results----\n";
		for (Racer racer : finished) {
			content += "Racer " + racer.num + " " + racer.finishTime() + "\n";
		}
		for (Racer racer : DNF) {
			content += "Racer " + racer.num + " DNF" + "\n";
		}

		out.writeBytes(content);
		out.flush();
		out.close();

		System.out.println("Done sent to server");

		InputStreamReader inputStr = new InputStreamReader(conn.getInputStream());

		StringBuilder sb = new StringBuilder();

		int nextChar;
		while ((nextChar = inputStr.read()) > -1) {
			sb = sb.append((char) nextChar);
		}
		System.out.println("Return String: " + sb);

	} catch (Exception e) {
		System.out.println("Could not send results to server");
	}
	}

}